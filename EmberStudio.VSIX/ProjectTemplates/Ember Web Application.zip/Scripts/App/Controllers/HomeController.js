﻿$safeprojectname$.HomeController = Ember.Controller.extend({
    message: 'Welcome to this app!'
});