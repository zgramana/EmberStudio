﻿$safeprojectname$.Router.map(function () {
    this.route("home", { path: "/home" });
    this.route("about", { path: "/about" });
});