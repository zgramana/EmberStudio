﻿$safeprojectname$.AboutController = Ember.Controller.extend({
    message: 'About this app.'
});