﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace $safeprojectname$.Controllers
{
    public class EmberController : Controller
    {
        //
        // GET: /Site/

        public ActionResult Index()
        {
            return View();
        }

    }
}
