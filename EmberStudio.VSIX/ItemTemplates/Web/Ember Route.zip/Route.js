// Replace `MyApp` with your App's name.
MyApp.$fileinputname$ = Ember.Route.extend({
	setupController: function (controller, model) {
	},
	renderTemplate: function (controller) {
	}
});